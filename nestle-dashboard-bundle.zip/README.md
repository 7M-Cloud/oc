# 🏭 Nestlé OCP Fleet Management Dashboard

**Enterprise Observability Dashboard for Nestlé OpenShift Container Platform Fleet**

Version: **4.0**  
Owner: **IT Platform Engineering — Datacenter Solutions Architecture**

---

## 📊 Nestlé Color Standard

| Status | Range | Color | Meaning |
|---|---|---|---|
| 🟢 Good | < 75% | Green | Healthy operating range |
| 🟡 Warning | 75 – 90% | Yellow/Amber | Monitor closely, plan capacity expansion |
| 🔴 Critical | > 90% | Red | Immediate action required |

Applied to: CPU/Memory request %, utilization %, storage used %, PVC used %, filesystem used %

---

## 🎯 Purpose

Single pane of glass for **capacity, availability, performance and health** across the entire Nestlé OCP fleet — from factory edge clusters to central datacenter hubs.

---

## 📋 Dashboard Sections

### Section 1 — Management Summary
- **Executive Summary**: 6 KPI tiles (Clusters Available, Nodes Ready %, Running Pods, Alerts, Operators Degraded)
- **Top 5 Stressed Clusters**: CPU / Memory / Disk / Pod Failures (color-coded by pressure)
- **Cluster Version Inventory**: All clusters with OCP version + health columns

### Section 2 — 🩺 Health Status
- **API + Ingress + Operators + etcd Health**: Real-time platform health
- **Pods in DOWN State**: Detailed list of Failed / Pending / Unknown pods
- **Namespace Workload + Quota Summary**: 16 columns including resource quotas inline
- **Pod Health Summary**: Top 30 pods by CPU / Memory / Restarts
- **Active Alerts**: Critical / Warning / Info breakdown with alert table

### Section 3 — 💾 Capacity (Per-Cluster Action View)
- **vCPU**: Fleet stats + per-cluster table with color-coded thresholds
- **Memory**: Fleet stats + per-cluster table
- **Storage**: Fleet stats + per-cluster PVC and disk I/O
- **Network**: Fleet stats + per-cluster throughput and drops

---

## 🚀 Deployment

### Method 1 — Automated Script
```bash
unzip nestle-ocp-fleet-mgmt-package.zip -d nestle-dashboard
cd nestle-dashboard
chmod +x deploy.sh
./deploy.sh
```

### Method 2 — Manual
```bash
unzip nestle-ocp-fleet-mgmt-package.zip -d nestle-dashboard
cd nestle-dashboard

# 1. Apply metrics allowlist
oc apply -f observability-metrics-custom-allowlist.yaml

# 2. Wait 90s for metric propagation
sleep 90

# 3. Apply dashboard (server-side apply REQUIRED)
oc apply -f nestle-ocp-fleet-mgmt.yaml \
  --server-side=true --force-conflicts

# 4. Verify
oc get cm nestle-ocp-fleet-mgmt -n open-cluster-management-observability

# 5. Get Grafana URL
echo "https://$(oc get route grafana -n open-cluster-management-observability -o jsonpath='{.spec.host}')"
```

### Method 3 — GitOps with ArgoCD (Recommended for production)
See `argocd-applicationset.yaml` included in this package.

---

## 🔍 Access the Dashboard

Navigate to:
```
Grafana → Dashboards → Browse → General →
   🏭 Nestlé OCP Fleet Management - Unified Observability
```

---

## 🌍 Multi-Hub Deployment

This dashboard is **100% ACM-agnostic** and can be deployed to all Nestlé ACM hubs:
- Datacenter hub (central operations)
- Regional hubs (EU / US / APAC)
- DR hub

Just `oc apply` the same files to each hub or use the included ArgoCD ApplicationSet.

---

## 🔁 Update / Remove

### Update to new version
```bash
oc apply -f nestle-ocp-fleet-mgmt.yaml \
  --server-side=true --force-conflicts
```

### Remove
```bash
oc delete cm nestle-ocp-fleet-mgmt \
  -n open-cluster-management-observability
```

Dashboard auto-removes from Grafana within 30 seconds.

---

## 🛠️ Troubleshooting

| Issue | Resolution |
|---|---|
| Dashboard not appearing | `oc rollout restart deploy/observability-grafana -n open-cluster-management-observability` |
| "annotation too long" | Always use `--server-side=true --force-conflicts` |
| "No Data" in panels | Wait 5–10 min after applying allowlist for metrics to flow |
| HAProxy panels empty | Enable HAProxy metrics on IngressController CR |
| Resource Quota empty | Verify ResourceQuota objects exist + `kube_resourcequota` metric collected |

---

## 📞 Support

- **Platform Engineering Team**: Internal Slack `#nestle-ocp-platform`
- **Documentation**: Internal wiki — `Nestle OCP Operations Guide`
- **On-call**: PagerDuty `Nestle OCP Platform`

---

## 📊 Dashboard Statistics

- **80** functional data panels
- **120+** PromQL queries
- **12** organized rows in 3 logical sections
- **8** cascading variables (cluster → namespace → pod drill-down)
- **100%** drill-down coverage on every panel
- **Color-coded thresholds** matching Nestlé operational standards
