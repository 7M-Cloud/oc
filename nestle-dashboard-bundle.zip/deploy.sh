#!/bin/bash
#
# Nestlé OCP Fleet Management Dashboard - Automated Deployment
# Version: 4.0
# Owner: IT Platform Engineering
#

set -e

NS="open-cluster-management-observability"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=================================================="
echo "  🏭 Nestlé OCP Fleet Management Dashboard v4.0"
echo "  Enterprise Observability Deployment"
echo "=================================================="
echo ""

echo "🔍 Step 0/6 - Verifying prerequisites..."
oc whoami --show-server || { echo "❌ Not logged in to OpenShift"; exit 1; }
oc get ns "$NS" >/dev/null 2>&1 || {
    echo "❌ Namespace $NS not found"
    echo "   ACM Observability is not enabled on this hub"
    exit 1
}
oc get deploy observability-grafana -n "$NS" >/dev/null 2>&1 || {
    echo "❌ observability-grafana deployment not found"
    exit 1
}
echo "✅ ACM Hub verified, Observability namespace exists, Grafana running"
echo ""

echo "📡 Step 1/6 - Applying metrics allowlist..."
oc apply -f observability-metrics-custom-allowlist.yaml
echo "✅ Allowlist applied"
echo ""

echo "⏳ Step 2/6 - Waiting 90s for metric propagation to managed clusters..."
sleep 90
echo "✅ Propagation wait complete"
echo ""

echo "📊 Step 3/6 - Deploying Nestlé OCP Fleet Management dashboard..."
oc apply -f nestle-ocp-fleet-mgmt.yaml \
  --server-side=true --force-conflicts
echo "✅ Dashboard ConfigMap applied"
echo ""

echo "✅ Step 4/6 - Verifying ConfigMap..."
oc get cm nestle-ocp-fleet-mgmt -n "$NS"
LABEL=$(oc get cm nestle-ocp-fleet-mgmt -n "$NS" \
  -o jsonpath='{.metadata.labels.grafana-custom-dashboard}')
if [ "$LABEL" != "true" ]; then
    echo "⚠️ grafana-custom-dashboard label incorrect"
    exit 1
fi
echo "✅ Auto-injection label verified"
echo ""

echo "🔍 Step 5/6 - Checking Grafana dashboard loader logs..."
sleep 15
LOG=$(oc logs -n "$NS" deploy/observability-grafana \
  -c grafana-dashboard-loader --tail=50 | grep -i "nestle" || true)
if [ -n "$LOG" ]; then
    echo "✅ Loader picked up dashboard:"
    echo "$LOG"
else
    echo "⚠️ Dashboard not yet visible in loader logs"
    echo "   Try: oc rollout restart deploy/observability-grafana -n $NS"
fi
echo ""

echo "🌐 Step 6/6 - Grafana URL:"
URL="https://$(oc get route grafana -n "$NS" -o jsonpath='{.spec.host}')"
echo "$URL"
echo ""
echo "📍 Navigate to: Dashboards → Browse → General →"
echo "   🏭 Nestlé OCP Fleet Management - Unified Observability"
echo ""
echo "=================================================="
echo "  ✅ Nestlé OCP Fleet Management v4.0 deployed!"
echo "=================================================="
