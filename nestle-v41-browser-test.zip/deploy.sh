#!/bin/bash
# Nestlé OCP Fleet Management Dashboard - Automated Deployment v4.1
set -e
NS="open-cluster-management-observability"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=================================================="
echo "  🏭 Nestlé OCP Fleet Management Dashboard v4.1"
echo "=================================================="

echo "🔍 Verifying prerequisites..."
oc whoami --show-server || { echo "❌ Not logged in"; exit 1; }
oc get ns "$NS" >/dev/null 2>&1 || { echo "❌ NS $NS not found"; exit 1; }
oc get deploy observability-grafana -n "$NS" >/dev/null 2>&1 || { echo "❌ Grafana not found"; exit 1; }
echo "✅ Prerequisites OK"

echo ""
echo "📡 Applying metrics allowlist..."
oc apply -f observability-metrics-custom-allowlist.yaml

echo ""
echo "⏳ Waiting 90s for metric propagation..."
sleep 90

echo ""
echo "📊 Deploying dashboard..."
oc apply -f nestle-ocp-fleet-mgmt.yaml --server-side=true --force-conflicts

echo ""
echo "✅ Verifying ConfigMap..."
oc get cm nestle-ocp-fleet-mgmt -n "$NS"

echo ""
echo "🔍 Checking loader..."
sleep 15
oc logs -n "$NS" deploy/observability-grafana -c grafana-dashboard-loader --tail=30 | grep -i nestle || echo "⚠️ Not yet visible"

echo ""
echo "🌐 Grafana URL:"
echo "https://$(oc get route grafana -n "$NS" -o jsonpath='{.spec.host}')"
echo "📍 Navigate: Dashboards → Browse → General → 🏭 Nestlé OCP Fleet Management"
echo ""
echo "✅ Deployment complete!"
