# 🏭 Nestlé OCP Fleet Management Dashboard v4.1

**Enterprise Observability Dashboard for Nestlé OpenShift Container Platform Fleet**

Owner: **IT Platform Engineering — Datacenter Solutions Architecture**

## 🎯 Purpose
Single pane of glass for capacity, availability, performance and health across the entire Nestlé OCP fleet.

## 📋 Dashboard Sections
### Section 1 — Management Summary
- Executive Summary (6 KPI tiles)
- Top 5 Stressed Clusters
- Cluster Version Inventory

### Section 2 — 🩺 Health Status
- API + Ingress + Operators + etcd Health
- Pods in DOWN State
- Namespace Workload + Quota Summary
- Pod Health Summary (Top 5)
- Active Alerts

### Section 3 — 💾 Capacity
- vCPU + CPU Usage by Namespace + CPU Quota table
- Memory + Memory Usage by Namespace + Memory Quota table
- Storage (PVC + Disk I/O)
- Network (Throughput + Drops)

## 🚀 Deployment
### Automated
```bash
chmod +x deploy.sh
./deploy.sh
```

### Manual
```bash
oc apply -f observability-metrics-custom-allowlist.yaml
sleep 90
oc apply -f nestle-ocp-fleet-mgmt.yaml --server-side=true --force-conflicts
```

Open Grafana → Dashboards → Browse → General → 🏭 Nestlé OCP Fleet Management

## 🔁 Update / Remove
```bash
# Update
oc apply -f nestle-ocp-fleet-mgmt.yaml --server-side=true --force-conflicts
# Remove
oc delete cm nestle-ocp-fleet-mgmt -n open-cluster-management-observability
```

## 🛠️ Troubleshooting
| Issue | Resolution |
|---|---|
| Dashboard not appearing | `oc rollout restart deploy/observability-grafana -n open-cluster-management-observability` |
| "annotation too long" | Always use `--server-side=true --force-conflicts` |
| "No Data" in panels | Wait 5-10 min after allowlist apply |
| HAProxy panels empty | Enable HAProxy metrics on IngressController |
