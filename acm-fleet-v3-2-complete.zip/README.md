# ACM Fleet - Unified Observability v3.2 (Streamlined + Cluster Inventory)

Single-pane-of-glass Grafana dashboard for Red Hat ACM, organized in 3 logical groups.

## 📊 Section 1 — Management Summary
- Executive Summary (6 KPI tiles)
- Fleet Availability + Top 5 Stressed Clusters
- **Cluster Version Inventory Table** (NEW — OpenShift version + node count + API status + operators + alerts per cluster)
- **OpenShift Version Distribution** bar gauge

## 🩺 Section 2 — Health Status
- API + Ingress + Operators + etcd + API Server Health
- Namespace Workload Table (with **Resource Quota Set** column)
- Pod Health & Drill-down
- Active Alerts

## 💾 Section 3 — Capacity Section
- vCPU / Memory / Storage / Network

## ✨ Key Features
- One-level drill-down on every panel
- Workload Scope toggle (Platform / Application / All)
- Clean table column headers (no `Value #A` artifacts)
- New: Cluster Version Inventory with color-coded health columns
- New: Resource Quota column in Namespace table
- API + Ingress availability time-series with HAProxy backend status

## 🚀 Deployment

### Quick Start
```bash
chmod +x deploy-v3-2.sh
./deploy-v3-2.sh
```

### Manual Steps
```bash
# 1. Apply allowlist
oc apply -f observability-metrics-custom-allowlist-v3.yaml

# 2. Wait for propagation
sleep 90

# 3. Deploy dashboard (server-side apply REQUIRED)
oc apply -f acm-fleet-unified-observability-v3-2.yaml \
  --server-side=true --force-conflicts

# 4. Verify
oc get cm acm-fleet-unified-observability-v3-2 \
  -n open-cluster-management-observability

# 5. Check loader
oc logs -n open-cluster-management-observability \
  deploy/observability-grafana -c grafana-dashboard-loader \
  --tail=20 | grep v3-2

# 6. Open Grafana
echo "https://$(oc get route grafana -n open-cluster-management-observability -o jsonpath='{.spec.host}')"
```

Navigate to: **Dashboards → Browse → General → ACM Fleet - Unified Observability v3.2 (Streamlined + Cluster Inventory)**

## 🆕 Cluster Version Inventory Table

The new table in Management Summary shows for each managed cluster:

| Column | Description |
|---|---|
| **Cluster** | Cluster name (clickable to drill in) |
| **OpenShift Version** | Current installed version |
| **Nodes Total** | Total number of nodes |
| **Nodes Ready** | Nodes in Ready state |
| **API Up** | API server availability (1=up, 0=down) - color coded |
| **Operators Degraded** | Number of degraded cluster operators - color coded |
| **Critical Alerts** | Active critical alerts on the cluster - color coded |

This gives a quick at-a-glance health and version inventory for the entire fleet.

## 🔄 Update / Remove

Update:
```bash
oc apply -f acm-fleet-unified-observability-v3-2.yaml \
  --server-side=true --force-conflicts
```

Remove:
```bash
oc delete cm acm-fleet-unified-observability-v3-2 \
  -n open-cluster-management-observability
```

## 🛠️ Troubleshooting

| Issue | Fix |
|---|---|
| Dashboard not showing | `oc rollout restart deploy/observability-grafana -n open-cluster-management-observability` |
| "annotation too long" | Always use `--server-side=true --force-conflicts` |
| "No Data" panels | Wait 5-10 min after applying allowlist |
| Version Inventory empty | Verify `cluster_version` metric is collected (in allowlist) |
| HAProxy panels empty | Enable HAProxy metrics on IngressController |
