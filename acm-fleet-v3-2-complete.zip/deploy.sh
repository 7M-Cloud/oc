#!/bin/bash
set -e
NS="open-cluster-management-observability"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "================================================"
echo "  ACM Fleet Unified Observability v3.2"
echo "  Streamlined + Cluster Version Inventory"
echo "================================================"
echo ""

echo "🔍 Step 0/6 - Verifying prerequisites..."
oc whoami --show-server || { echo "❌ Not logged in to OpenShift"; exit 1; }
oc get ns "$NS" >/dev/null 2>&1 || { echo "❌ Namespace $NS not found"; exit 1; }
oc get deploy observability-grafana -n "$NS" >/dev/null 2>&1 || { echo "❌ Grafana deployment not found"; exit 1; }
echo "✅ Prerequisites OK"; echo ""

echo "📡 Step 1/6 - Applying metrics allowlist..."
oc apply -f observability-metrics-custom-allowlist-v3.yaml
echo "✅ Allowlist applied"; echo ""

echo "⏳ Step 2/6 - Waiting 90s for metric propagation..."
sleep 90
echo "✅ Wait complete"; echo ""

echo "📊 Step 3/6 - Deploying v3.2 dashboard (server-side apply)..."
oc apply -f acm-fleet-unified-observability-v3-2.yaml \
  --server-side=true --force-conflicts
echo "✅ Dashboard applied"; echo ""

echo "✅ Step 4/6 - Verifying ConfigMap..."
oc get cm acm-fleet-unified-observability-v3-2 -n "$NS"
echo ""

echo "🔍 Step 5/6 - Checking Grafana loader (waiting 15s)..."
sleep 15
LOG=$(oc logs -n "$NS" deploy/observability-grafana -c grafana-dashboard-loader --tail=50 | grep -i "v3-2" || true)
if [ -n "$LOG" ]; then echo "✅ Loader:"; echo "$LOG"; else echo "⚠️ Not yet visible - try restarting Grafana"; fi
echo ""

echo "🌐 Step 6/6 - Grafana URL:"
echo "https://$(oc get route grafana -n "$NS" -o jsonpath='{.spec.host}')"
echo ""
echo "📍 Navigate: Dashboards → Browse → General → ACM Fleet - Unified Observability v3.2"
echo ""
echo "================================================"
echo "  ✅ v3.2 deployment complete!"
echo "================================================"
