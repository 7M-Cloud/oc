# ACM Fleet - Unified Observability v3.3

## 🆕 What's New in v3.3
- ✅ **Removed** top "Management Summary" header divider
- ✅ **NEW: Pods in DOWN State table** — detailed list with cluster + namespace + pod + phase + waiting reason
- ✅ **NEW: Namespace Resource Quota Status table** — CPU/Memory/Storage/Pods hard vs used
- ✅ **FIXED: Pod Summary tables** — now uses simpler top-30 per metric structure (3 tables side by side)
- ✅ **FIXED: Drill-down links** — uses `${__value.text}` for reliable navigation

## 📊 Dashboard Structure

### Section 1 — Management Summary (no header)
- Row 1: Executive Summary (6 KPI tiles)
- Row 2: Fleet Availability + Top 5 Stressed Clusters
- Row 3: Cluster Version Inventory

### Section 2 — 🩺 Health Status
- Row 4: API + Ingress + Operators + etcd Health
- **Row 5: Pods in DOWN State - Detailed List (NEW)**
- **Row 6: Namespace Resource Quota Status (NEW)**
- Row 7: Namespace Workload Health Table (with Resource Quota Set column)
- Row 8: Pod Health Summary (3 tables side-by-side: CPU / Memory / Restarts)
- Row 9: Active Alerts

### Section 3 — 💾 Capacity Section
- Row 10: vCPU
- Row 11: Memory
- Row 12: Storage
- Row 13: Network

## 🚀 Deployment

### Automated
```bash
chmod +x deploy.sh
./deploy.sh
```

### Manual
```bash
# 1. Allowlist
oc apply -f observability-metrics-custom-allowlist.yaml

# 2. Wait 90s
sleep 90

# 3. Dashboard
oc apply -f acm-fleet-unified-observability-v3-3.yaml \
  --server-side=true --force-conflicts

# 4. Open Grafana
echo "https://$(oc get route grafana -n open-cluster-management-observability -o jsonpath='{.spec.host}')"
```

Navigate: **Dashboards → Browse → General → ACM Fleet - Unified Observability v3.3**

## 🔁 Update / Remove
```bash
# Update
oc apply -f acm-fleet-unified-observability-v3-3.yaml --server-side=true --force-conflicts

# Remove
oc delete cm acm-fleet-unified-observability-v3-3 -n open-cluster-management-observability
```
