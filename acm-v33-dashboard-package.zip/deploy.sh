#!/bin/bash
set -e
NS="open-cluster-management-observability"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "================================================"
echo "  ACM Fleet Unified Observability v3.3"
echo "  Pods Down State + Quota Details"
echo "================================================"

echo "🔍 Step 0: Verifying prerequisites..."
oc whoami --show-server || { echo "❌ Not logged in"; exit 1; }
oc get ns "$NS" >/dev/null 2>&1 || { echo "❌ NS $NS not found"; exit 1; }
echo "✅ Prerequisites OK"

echo ""
echo "📡 Step 1: Applying allowlist..."
oc apply -f observability-metrics-custom-allowlist.yaml

echo ""
echo "⏳ Step 2: Waiting 90s..."
sleep 90

echo ""
echo "📊 Step 3: Deploying dashboard..."
oc apply -f acm-fleet-unified-observability-v3-3.yaml \
  --server-side=true --force-conflicts

echo ""
echo "✅ Step 4: Verifying..."
oc get cm acm-fleet-unified-observability-v3-3 -n "$NS"

echo ""
echo "🔍 Step 5: Checking loader..."
sleep 15
oc logs -n "$NS" deploy/observability-grafana -c grafana-dashboard-loader --tail=30 | grep -i "v3-3" || echo "⚠️ Not yet visible"

echo ""
echo "🌐 Grafana URL:"
echo "https://$(oc get route grafana -n "$NS" -o jsonpath='{.spec.host}')"
echo ""
echo "📍 Navigate: Dashboards → Browse → General → ACM Fleet - Unified Observability v3.3"
echo ""
echo "✅ Deployment complete!"
