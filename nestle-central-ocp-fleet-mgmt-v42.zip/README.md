# Nestlé Central OCP Fleet Management Dashboard v4.2

Central Grafana dashboard for the complete Nestlé OpenShift fleet.

## New in v4.2
- CPU/Memory Commitment % KPIs
- CPU/Memory Limit Overcommit % KPIs
- Overcommit Detection by Cluster
- Namespace Limit vs Request Gap Analysis
- Action-driven alert and capacity recommendations
- Central-only wording and operation model

## Deploy

```bash
oc apply -f observability-metrics-custom-allowlist.yaml
sleep 90
oc apply -f nestle-central-ocp-fleet-mgmt-v42.yaml --server-side=true --force-conflicts
```

Open Grafana → Dashboards → Browse → General → Nestlé Central OCP Fleet Management - Unified Observability v4.2
