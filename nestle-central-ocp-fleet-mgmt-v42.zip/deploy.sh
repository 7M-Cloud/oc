#!/bin/bash
set -e
NS="open-cluster-management-observability"
oc apply -f observability-metrics-custom-allowlist.yaml
sleep 90
oc apply -f nestle-central-ocp-fleet-mgmt-v42.yaml --server-side=true --force-conflicts
oc get cm nestle-central-ocp-fleet-mgmt-v42 -n "$NS"
echo "Grafana URL: https://$(oc get route grafana -n $NS -o jsonpath='{.spec.host}')"
